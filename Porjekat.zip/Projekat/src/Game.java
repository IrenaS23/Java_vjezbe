import java.util.ArrayList;

public class Game {
    private Player player;
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private ArrayList<String> log = new ArrayList<>();

    public Game(Player player) {
        this.player = player;
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        log.add("Enemy added: " + e.getDisplayName());
    }

    public void checkCollisions() {
        for (Enemy e : enemies) {
            if (player.intersects(e)) {
                log.add("HIT: " + e.getDisplayName() + " dealt " + e.getDamage());
                player.decreaseHealth(e.getDamage());
            }
        }
    }

    public void printStatus() {
        System.out.println("Player health: " + player.getHealth());
    }

    public void printLog() {
        for (String s : log)
            System.out.println(s);
    }
}
