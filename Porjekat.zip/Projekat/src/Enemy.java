public abstract class Enemy extends GameObject {
    protected int damage;

    public Enemy(double x, double y, Collider collider, int damage) {
        super(x, y, collider);

        if (damage < 0) throw new IllegalArgumentException("Damage ne moze biti negativan");

        this.damage = damage;
    }

    public int getDamage() {
        return damage;
    }
}
