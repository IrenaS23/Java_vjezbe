public class CircleCollider extends Collider {
    double radius;

    public CircleCollider(double x, double y, double radius) {
        super(x, y);

        if (radius <= 0)
            throw new IllegalArgumentException("Poluprecnik mora biti > 0");

        this.radius = radius;
    }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;

            double dx = x - c.x;
            double dy = y - c.y;

            double dist = dx * dx + dy * dy;
            double sum = radius + c.radius;

            return dist <= sum * sum;
        }

        else if (other instanceof RectangleCollider) {
            return other.intersects(this);
        }

        return false;
    }
}
