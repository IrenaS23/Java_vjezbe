public abstract class GameObject {
    protected double x;
    protected double y;
    protected Collider collider;

    public GameObject(double x, double y, Collider collider) {
        this.x = x;
        this.y = y;
        this.collider = collider;
    }

    public boolean intersects(GameObject other) {
        return collider.intersects(other.collider);
    }

    public abstract String getDisplayName();

    @Override
    public String toString() {
        return getDisplayName() + " at (" + x + "," + y + ")";
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
