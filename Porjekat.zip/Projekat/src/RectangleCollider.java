
public class RectangleCollider extends Collider {
    private double width;
    private double height;

    public RectangleCollider(double x, double y, double width, double height) {
        super(x, y);

        if (width <= 0 || height <= 0)
            throw new IllegalArgumentException("Dimenzije moraju biti > 0");

        this.width = width;
        this.height = height;
    }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;

            return !(x + width < r.x || r.x + r.width < x ||
                     y + height < r.y || r.y + r.height < y);
        }

        else if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;

            double closestX = Math.max(x, Math.min(c.x, x + width));
            double closestY = Math.max(y, Math.min(c.y, y + height));

            double dx = c.x - closestX;
            double dy = c.y - closestY;

            return dx * dx + dy * dy <= c.radius * c.radius;
        }

        return false;
    }
}
