
public abstract class Collider implements Collidable {
    protected double x;
    protected double y;

    public Collider(double x, double y) {
        this.x = x;
        this.y = y;
    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
