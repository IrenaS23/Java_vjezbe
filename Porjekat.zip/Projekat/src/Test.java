
public class Test {

	public static void main(String[] args) {
		  Player p = new Player(
	                "Hero",
	                5, 5,
	                new RectangleCollider(5, 5, 2, 2),
	                100
	        );

	        Game game = new Game(p);

	        game.addEnemy(new MeleeEnemy(6, 5, new RectangleCollider(6, 5, 2, 2), 10));
	        game.addEnemy(new BossEnemy(10, 10, new CircleCollider(10, 10, 3), 20));

	        game.checkCollisions();

	        game.printStatus();
	        game.printLog();
	    }
	}