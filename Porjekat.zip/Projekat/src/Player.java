public class Player extends GameObject {
    private String ime;
    private int health;

    public Player(String ime, double x, double y, Collider collider, int health) {
        super(x, y, collider);

        if (ime == null || ime.trim().isEmpty())
            throw new IllegalArgumentException("Ime ne moze biti prazno");

        this.ime = ime;
        this.health = health;
    }

    public void decreaseHealth(int dmg) {
        health -= dmg;
        if (health < 0) health = 0;
    }

    public int getHealth() {
        return health;
    }

    @Override
    public String getDisplayName() {
        return ime;
    }
}
