public class MeleeEnemy extends Enemy {

    public MeleeEnemy(double x, double y, Collider collider, int damage) {
        super(x, y, collider, damage);
    }

    @Override
    public String getDisplayName() {
        return "MeleeEnemy";
    }
}
