public class BossEnemy extends Enemy {

    public BossEnemy(double x, double y, Collider collider, int damage) {
        super(x, y, collider, damage * 2);
    }

    @Override
    public String getDisplayName() {
        return "BossEnemy";
    }
}
