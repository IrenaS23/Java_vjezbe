package nedelja4;

public class zadatak1 {

	public static void main(String[] args) {
		int [] niz = new int[10];
		for (int i=0; i<niz.length;i++) {
			niz[i] = i+1;
		}
		for (int i = 9; i>=10; i--) {
			System.out.println(niz[i]);
		}

	}

}
