package nedelja4;

import java.util.Scanner;

public class FudbalskaUtakmica {
//bubble sort najjednostavniji sort 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Unesite duzinu niza: ");
		int velicinaNiza = sc.nextInt();
		int[] brojevi= new int[velicinaNiza];
		
		for (int i=0;i<brojevi.length; i++) {
			System.out.println("Unesite" +(i+1)+"el niza");
			brojevi[i]=sc.nextInt();
		}

		for(int i=0;i<brojevi.length -1;i++) {
			for(int j=0; j<brojevi.length -i -1;j++) {
				if(brojevi[i]> brojevi[i+1]) {
					int temp= brojevi[j];
					brojevi[j]=brojevi[j+1];
					brojevi[j+1]=temp;
					
				}
				
			}
		}
		for(int x:brojevi) {
			System.out.println(x);
		}
	}

	}