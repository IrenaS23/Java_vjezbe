package nedelja4;

import java.util.Arrays;
import java.util.Scanner;

public class EvidencijaTemp {
	
	    private double[] temperature;

	 
	    public EvidencijaTemp(double[] temperature) { this.temperature = temperature; }
	    public double[] getTemperature() {return temperature; }
	    public void setTemperature(double[] temperature) {this.temperature = temperature;  }

	    // prosjekk
	    public double prosjTemp(double[] niz) {
	        double suma = 0;
	        for (double temp : niz) {
	            suma += temp;
	        }
	        return suma / niz.length;
	    }

	    // Max temp
	    public double maxTemp(double[] niz) {
	        double max = niz[0];
	        for (double temp : niz) {
	            if (temp > max)
	                max = temp;
	        }
	        return max;
	    }

	   
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        double[] niz = new double[5];
	        System.out.println("Unesite 5 temperatura:");
	        for (int i = 0; i < niz.length; i++) {
	            niz[i] = sc.nextDouble();
	        }

	        EvidencijaTemp e= new EvidencijaTemp(niz);

	        
	        System.out.println("\nDužina niza: " + e.getTemperature().length);
	      

	        // Da li se nalazi?
	        System.out.print("Unesite temp za provjeru: ");
	        double t = sc.nextDouble();
	        boolean postoji = false;
	        for (double temp : e.getTemperature()) {
	            if (temp == t) {
	                postoji = true;
	                break;
	            }
	        }
	        System.out.println(postoji ? "Temperatura se nalazi u nizu." : "Temperatura se ne nalazi u nizu.");

	       

	    }
	}


