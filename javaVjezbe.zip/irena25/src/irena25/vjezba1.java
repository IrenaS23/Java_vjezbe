package irena25;

import java.util.Scanner;

public class vjezba1 {

	public static void main(String[] args) {
		//ZADATAKK SA DVORCEM.....
	
		        Scanner sc = new Scanner(System.in);

		        System.out.println("Unesi broj katapulta N:");
		        int N = sc.nextInt();

		        System.out.println("Unesi max distancu za domet :");
		        int D = sc.nextInt();

		        System.out.println("Unesi health dvorca HD:");
		        int HD = sc.nextInt();

		        System.out.println("Unesi napad jednog katapulta KA:");
		        int KA = sc.nextInt();
		        int BrKatapultaIzDometa = 0;

		       for(int i=0; i<N; i++) {
		    	   int xKatapulta = sc.nextInt();
		    	   int yKatapulta = sc.nextInt();
		    	   int menhetnRastojanje = Math.abs(xKatapulta)+ Math.abs(yKatapulta);
		    	   if (menhetnRastojanje<=D) {
		    		   BrKatapultaIzDometa++;
		    		   
		    	   }
		    	   if(BrKatapultaIzDometa*KA>=HD) {
		    		   System.out.println("Dvorac je srusen");
		    	   }else{
		    		   System.out.println("Dvorac nije srusen");
		    	   }
		    	   
		       }
	
	}}
		       
		


