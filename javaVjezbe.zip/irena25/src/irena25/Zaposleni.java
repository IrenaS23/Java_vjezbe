package irena25;

public class Zaposleni {
	 private String ime;
	 private String prezime;
	 private int godine_staza;
	 private double plata;
	 
	 
	public Zaposleni(String ime, String prezime, int godine_staza, double plata) {
		this.ime = ime;
		this.prezime = prezime;
		this.godine_staza = godine_staza;
		this.plata = plata;
	}


	public String getIme() {
		return ime;
	}


	public void setIme(String ime) {
		this.ime = ime;
	}


	public String getPrezime() {
		return prezime;
	}


	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}


	public int getGodine_staza() {
		return godine_staza;
	}


	public void setGodine_staza(int godine_staza) {
		this.godine_staza = godine_staza;
	}


	public double getPlata() {
		return plata;
	}


	public void setPlata(double plata) {
		this.plata = plata;
	}

 public void ispisZaposlenog() {
	 System.out.println(ime+" "+ prezime+" "+ "godine staza: "+ godine_staza );
 }
 
 public void povecajPlatu() {
     if (plata < 800 && godine_staza > 10) {
         plata = plata + plata * 0.06;
     }
 }
     public static void ispisiNajvecuPlatu(Zaposleni[] niz) {
         if (niz.length == 0) return;

         Zaposleni najplaceniji = niz[0];
         for (Zaposleni z : niz) {
             if (z.getPlata() > najplaceniji.getPlata()) {
                 najplaceniji = z;
             }
         }
         System.out.println("Zaposleni s naj platom: " + najplaceniji.getIme() + " " + najplaceniji.getPrezime() + " - plata: " + najplaceniji.getPlata());
 }
	public static void main(String[] args) {
		Zaposleni z1 = new Zaposleni("Marko", "Markovic", 12, 750);
        Zaposleni z2 = new Zaposleni("Nina", "Maras", 8, 900);
        Zaposleni z3 = new Zaposleni("Ivona", "Dabovic", 15, 780);
        Zaposleni z4 = new Zaposleni("Jelena", "Pavicevic", 5, 850);
        Zaposleni z5 = new Zaposleni("Irena", "Mandic", 20, 1200);

     
        Zaposleni[] zaposleniNiz = {z1, z2, z3, z4, z5};
	}
	
     }


