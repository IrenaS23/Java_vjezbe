package irena25;

public class Televizor {
	private int brojKanala;
	private String nazivKanala;
	private int jacinaTona;

	
	public Televizor(int brojKanala, String nazivKanala, int jacinaTona) {
		this.brojKanala = brojKanala;
		this.nazivKanala = nazivKanala;
		this.jacinaTona = jacinaTona;
	}


	public int getBrojKanala() {
		return brojKanala;
	}


	public void setBrojKanala(int brojKanala) {
		if(brojKanala>=1) {
		this.brojKanala = brojKanala;	
		}else {
		   this.brojKanala	=1;
		}
		
	}


	public String getNazivKanala() {
		return nazivKanala;
	}


	public void setNazivKanala(String nazivKanala) {
		this.nazivKanala = nazivKanala;
	}


	public int getJacinaTona() {
		return jacinaTona;
	}


	public void setJacinaTona(int jacinaTona) {
		if(jacinaTona>=0 && jacinaTona<=10) {
		this.jacinaTona = jacinaTona;	
		}else {
			this.jacinaTona=5;
		}
		
		}
	public void pojacajTon() {
		if(this.jacinaTona<10) {
			this.jacinaTona++;
		}else{
			System.out.println("Jacina Tona vec na max");
		}
	
	}


	public static void main(String[] args) {
		Televizor televizor1 = new Televizor(10,"Pink",6);
		System.out.println("Broj kanala" + televizor1.brojKanala);
		Televizor televizor2 = new Televizor(12,"Pink",5);
		System.out.println("Broj kanala" + televizor2.brojKanala);
		televizor2.pojacajTon();
		televizor1.pojacajTon();
	}

}
