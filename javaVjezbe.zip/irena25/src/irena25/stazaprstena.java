package irena25;

import java.util.Scanner;

public class stazaprstena {

	public static void main(String[] args) {
	     Scanner sc = new Scanner(System.in);

	        System.out.println("Unesi koordinate centra :");
	        double cx = sc.nextDouble();
	        double cy = sc.nextDouble();

	        System.out.println("Unesi poluprecnike R1 i :");
	        double R1 = sc.nextDouble();
	        double R2 = sc.nextDouble();

	        System.out.println("Unesi broj trkaca N:");
	        int N = sc.nextInt();
	        System.out.println("Unesi koordinate trkaca:");
	        for (int i = 0; i < N; i++) {
	            double xi = sc.nextDouble();
	            double yi = sc.nextDouble();

	        int TrkaciPrstenu = 0;
	        int maxDist=1;
	       

	            double dist = Math.sqrt((xi - cx) * (xi - cx) + (yi - cy) * (yi - cy));

	            if (dist >= R1 && dist <= R2) {
	            	TrkaciPrstenu++;
	            }

	           

	        System.out.println("\nBroj trkaca u prstenu: " + TrkaciPrstenu);
	        System.out.println("Najudaljeniji trkac:  sa udaljenoscu " + maxDist);

	        sc.close();
	    }
	}
	        
	        
	        
	}


