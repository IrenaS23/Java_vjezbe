import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;


interface Collidable {
    boolean intersects(Collidable other);
}

class RectangleCollider implements Collidable {
    private int x;
    private int y;
    private int width;
    private int height;

    RectangleCollider(int x, int y, int width, int height) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("Invalid rectangle size");
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    int left() { return x; }
    int top() { return y; }
    int right() { return x + width; }
    int bottom() { return y + height; }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;
            return this.left() < r.right() && this.right() > r.left() && this.top() < r.bottom() && this.bottom() > r.top();
        } else if (other instanceof CircleCollider) {
            return other.intersects(this);
        }
        return false;
    }
}

class CircleCollider implements Collidable {
    private int cx;
    private int cy;
    private int radius;

    CircleCollider(int cx, int cy, int radius) {
        if (radius <= 0) throw new IllegalArgumentException("Invalid radius");
        this.cx = cx;
        this.cy = cy;
        this.radius = radius;
    }

    static int clamp(int v, int min, int max) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;
            long dx = (long) this.cx - c.cx;
            long dy = (long) this.cy - c.cy;
            long r = (long) this.radius + c.radius;
            return dx * dx + dy * dy <= r * r;
        } else if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;
            int nearestX = clamp(cx, r.left(), r.right());
            int nearestY = clamp(cy, r.top(), r.bottom());
            long dx = (long) cx - nearestX;
            long dy = (long) cy - nearestY;
            return dx * dx + dy * dy <= (long) radius * radius;
        }
        return false;
    }
}

abstract class GameObject {
    private int x;
    private int y;
    private Collidable collider;

    GameObject(int x, int y, Collidable collider) {
        if (collider == null) throw new IllegalArgumentException("Collider null");
        this.x = x;
        this.y = y;
        this.collider = collider;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public Collidable getCollider() { return collider; }
    public void setCollider(Collidable c) { if (c == null) throw new IllegalArgumentException("Collider null"); this.collider = c; }

    public boolean intersects(GameObject other) {
        return this.collider.intersects(other.collider);
    }

    public abstract String getDisplayName();

    @Override
    public String toString() {
        return "Object(" + getDisplayName() + ") @(" + x + "," + y + ")";
    }
}

class Player extends GameObject {
    private String name;
    private int health;

    Player(int x, int y, Collidable collider, String name, int health) {
        super(x, y, collider);
        String n = name == null ? "" : name.trim();
        if (!n.isEmpty()) {
            if (!Character.isUpperCase(n.charAt(0))) n = Character.toUpperCase(n.charAt(0)) + (n.length() > 1 ? n.substring(1) : "");
        }
        if (n.isEmpty()) throw new IllegalArgumentException("Invalid name");
        if (health < 0 || health > 100) throw new IllegalArgumentException("Invalid health");
        this.name = n;
        this.health = health;
    }

    public String getName() { return name; }
    public int getHealth() { return health; }
    public void setHealth(int h) { this.health = Math.max(0, Math.min(100, h)); }

    @Override
    public String getDisplayName() { return name; }

    @Override
    public String toString() {
        return "Player{name='" + name + "', health=" + health + ", x=" + getX() + ", y=" + getY() + "}";
    }
}

interface Attacker {
    int getEffectiveDamage();
}

abstract class Enemy extends GameObject implements Attacker {
    private String type;
    private int damage;
    private int health;

    Enemy(int x, int y, Collidable collider, String type, int damage, int health) {
        super(x, y, collider);
        String t = type == null ? "" : type.trim();
        if (t.isEmpty()) throw new IllegalArgumentException("Invalid type");
        if (damage < 0 || damage > 100) throw new IllegalArgumentException("Invalid damage");
        if (health < 0 || health > 100) throw new IllegalArgumentException("Invalid health");
        this.type = t;
        this.damage = damage;
        this.health = health;
    }

    public String getType() { return type; }
    public int getDamage() { return damage; }
    public int getHealth() { return health; }

    @Override
    public int getEffectiveDamage() { return damage; }

    @Override
    public String getDisplayName() { return type; }

    @Override
    public String toString() {
        return "Enemy{" + getClass().getSimpleName() + ", type='" + type + "', dmg=" + damage + ", hp=" + health + ", x=" + getX() + ", y=" + getY() + "}";
    }
}

class MeleeEnemy extends Enemy {
    MeleeEnemy(int x, int y, Collidable collider, String type, int damage, int health) {
        super(x, y, collider, type, damage, health);
    }
}

class BossEnemy extends Enemy {
    BossEnemy(int x, int y, Collidable collider, String type, int damage, int health) {
        super(x, y, collider, type, damage, health);
    }

    @Override
    public int getEffectiveDamage() { return super.getEffectiveDamage() * 2; }

    @Override
    public String toString() {
        return "Boss{" + getDisplayName() + ", effDmg=" + getEffectiveDamage() + ", x=" + getX() + ", y=" + getY() + "}";
    }
}

class Game {
    private Player player;
    private ArrayList<Enemy> enemies = new ArrayList<>();
    private ArrayList<String> log = new ArrayList<>();

    Game(Player player) {
        this.player = player;
    }

    public Player getPlayer() { return player; }
    public List<Enemy> getEnemies() { return enemies; }
    public List<String> getLog() { return log; }

    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        int before = p.getHealth();
        int after = Math.max(0, before - e.getEffectiveDamage());
        p.setHealth(after);
        log.add("Hit by " + e.getDisplayName() + " for " + e.getEffectiveDamage() + ", health: " + before + " -> " + after);
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        log.add("Enemy added: " + e.toString());
    }

    public List<Enemy> findByType(String query) {
        ArrayList<Enemy> res = new ArrayList<>();
        String q = query == null ? "" : query.toLowerCase();
        for (Enemy e : enemies) if (e.getDisplayName().toLowerCase().contains(q)) res.add(e);
        return res;
    }

    public List<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> res = new ArrayList<>();
        for (Enemy e : enemies) if (checkCollision(player, e)) res.add(e);
        return res;
    }

    public void resolveCollisions() {
        for (Enemy e : enemies) if (checkCollision(player, e)) decreaseHealth(player, e);
    }

    public static List<Enemy> loadEnemiesFromCSV(String filePath) {
        ArrayList<Enemy> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
                if (parts.length < 7) throw new IllegalArgumentException("Invalid CSV line");
                String type = parts[0];
                String kind = parts[1].toLowerCase();
                int x = Integer.parseInt(parts[2]);
                int y = Integer.parseInt(parts[3]);
                String shape = parts[4].toLowerCase();
                Collidable col;
                int damage;
                int health;
                if (shape.equals("rectangle") || shape.equals("rect") || shape.equals("r")) {
                    if (parts.length < 9) throw new IllegalArgumentException("Invalid rectangle line");
                    int w = Integer.parseInt(parts[5]);
                    int h = Integer.parseInt(parts[6]);
                    damage = Integer.parseInt(parts[7]);
                    health = Integer.parseInt(parts[8]);
                    col = new RectangleCollider(x, y, w, h);
                } else if (shape.equals("circle") || shape.equals("c")) {
                    if (parts.length < 8) throw new IllegalArgumentException("Invalid circle line");
                    int r = Integer.parseInt(parts[5]);
                    damage = Integer.parseInt(parts[6]);
                    health = Integer.parseInt(parts[7]);
                    col = new CircleCollider(x, y, r);
                } else {
                    throw new IllegalArgumentException("Unknown shape");
                }
                if (damage < 0 || damage > 100) throw new IllegalArgumentException("Invalid damage");
                if (health < 0 || health > 100) throw new IllegalArgumentException("Invalid health");
                Enemy e;
                if (kind.equals("melee")) e = new MeleeEnemy(x, y, col, type, damage, health);
                else if (kind.equals("boss")) e = new BossEnemy(x, y, col, type, damage, health);
                else throw new IllegalArgumentException("Unknown enemy class");
                list.add(e);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return list;
    }
}

public class GameApp {
    private JFrame frame;
    private JTextField nameField;
    private JTextField healthField;
    private JTextField xField;
    private JTextField yField;
    private JComboBox<String> colliderBox;
    private JTextField csvField;
    private JTextArea outputArea;

    public GameApp() {
        frame = new JFrame("Projekat 5");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 600);
        frame.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        nameField = new JTextField();
        healthField = new JTextField("100");
        xField = new JTextField("0");
        yField = new JTextField("0");
        colliderBox = new JComboBox<>(new String[]{"rectangle", "circle"});
        csvField = new JTextField("enemies.csv");

        form.add(new JLabel("Ime:"));
        form.add(nameField);
        form.add(new JLabel("Health (0-100):"));
        form.add(healthField);
        form.add(new JLabel("X:"));
        form.add(xField);
        form.add(new JLabel("Y:"));
        form.add(yField);
        form.add(new JLabel("Collider:"));
        form.add(colliderBox);
        form.add(new JLabel("CSV fajl:"));
        form.add(csvField);

        JButton run = new JButton("Pokreni igru");
        run.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                runGame();
            }
        });

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(outputArea);

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(run, BorderLayout.SOUTH);

        frame.add(top, BorderLayout.NORTH);
        frame.add(scroll, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void runGame() {
        try {
            String name = nameField.getText();
            int health = Integer.parseInt(healthField.getText().trim());
            int x = Integer.parseInt(xField.getText().trim());
            int y = Integer.parseInt(yField.getText().trim());
            String colType = Objects.toString(colliderBox.getSelectedItem(), "rectangle").toLowerCase();
            Collidable col = colType.equals("circle") ? new CircleCollider(x, y, 16) : new RectangleCollider(x, y, 32, 32);
            Player p = new Player(x, y, col, name, health);
            Game game = new Game(p);
            String path = csvField.getText().trim();
            for (Enemy e : Game.loadEnemiesFromCSV(path)) game.addEnemy(e);
            List<Enemy> colliding = game.collidingWithPlayer();
            game.resolveCollisions();

            StringBuilder sb = new StringBuilder();
            sb.append("Igrac:\n");
            sb.append(game.getPlayer().toString()).append("\n\n");
            sb.append("Neprijatelji:\n");
            for (Enemy e : game.getEnemies()) sb.append(e.toString()).append("\n");
            sb.append("\nU koliziji sa igracem:\n");
            for (Enemy e : colliding) sb.append(e.toString()).append("\n");
            sb.append("\nLog:\n");
            for (String s : game.getLog()) sb.append(s).append("\n");
            outputArea.setText(sb.toString());

            if (game.getPlayer().getHealth() == 0) JOptionPane.showMessageDialog(frame, "Igrac je porazen.");
            else JOptionPane.showMessageDialog(frame, "Igrac je prezivio. Health: " + game.getPlayer().getHealth());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, ex.getMessage(), "Greska", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GameApp();
            }
        });
    }
}
