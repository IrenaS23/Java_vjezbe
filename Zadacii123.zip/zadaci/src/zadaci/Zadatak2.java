package zadaci;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Zadatak2 extends JFrame {
    JTextField unos;
    JButton dugme;

    public Zadatak2() {
        setTitle("Izraz");
        setLayout(new FlowLayout());
        setSize(250, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        unos = new JTextField(10);
        dugme = new JButton("Izracunaj");

        dugme.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String izraz = unos.getText();
                double rez = 0;
                char op = ' ';

                if (izraz.contains("+")) op = '+';
                else if (izraz.contains("-")) op = '-';
                else if (izraz.contains("*")) op = '*';
                else if (izraz.contains("/")) op = '/';

                int i = izraz.indexOf(op);
                double a = Double.parseDouble(izraz.substring(0, i));
                double b = Double.parseDouble(izraz.substring(i + 1));

                if (op == '+') rez = a + b;
                else if (op == '-') rez = a - b;
                else if (op == '*') rez = a * b;
                else if (op == '/') rez = a / b;

                JOptionPane.showMessageDialog(null, "Rezultat: " + rez);
            }
        });

        add(new JLabel("Unesite izraz:"));
        add(unos);
        add(dugme);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Zadatak2();
    }
}

