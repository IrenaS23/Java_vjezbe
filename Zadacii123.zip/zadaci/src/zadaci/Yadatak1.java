package zadaci;

import javax.swing.JOptionPane;

public class Yadatak1 {
    public static void main(String[] args) {
        String ime = JOptionPane.showInputDialog("Unesite ime:");
        String prezime = JOptionPane.showInputDialog("Unesite prezime:");
        String godina = JOptionPane.showInputDialog("Unesite godinu rodjenja:");

        String prikaz = "Pregled podataka:\nIme: " + ime + "\nPrezime: " + prezime + "\nGodina rodjenja: " + godina + "\nDa li su podaci tacni?";
        int potvrda = JOptionPane.showConfirmDialog(null, prikaz, "Potvrda", JOptionPane.YES_NO_OPTION);

        if (potvrda == JOptionPane.YES_OPTION) {
            String email = ime + "." + prezime + godina + "@kompanija.me";
            JOptionPane.showMessageDialog(null, "Vasa email adresa je: " + email);
        } else {
            JOptionPane.showMessageDialog(null, "Unesite ponovo podatke.");
        }
    }
}
