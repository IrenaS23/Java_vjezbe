package zadaci;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Zadatak3 extends JFrame {
    JTextField eur, usd, gbp;
    double kursEurUsd = 1.08;
    double kursEurGbp = 0.85;

    public Zadatak3() {
        setTitle("Konverzija");
        setLayout(new GridLayout(3, 2, 5, 5));
        setSize(250, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        add(new JLabel("EUR"));
        eur = new JTextField();
        add(eur);

        add(new JLabel("USD"));
        usd = new JTextField();
        add(usd);

        add(new JLabel("GBP"));
        gbp = new JTextField();
        add(gbp);

        eur.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (!eur.getText().isEmpty()) {
                    double iznos = Double.parseDouble(eur.getText());
                    usd.setText(String.format("%.2f", iznos * kursEurUsd));
                    gbp.setText(String.format("%.2f", iznos * kursEurGbp));
                } else {
                    usd.setText("");
                    gbp.setText("");
                }
            }
        });

        usd.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (!usd.getText().isEmpty()) {
                    double iznos = Double.parseDouble(usd.getText());
                    double eurV = iznos / kursEurUsd;
                    eur.setText(String.format("%.2f", eurV));
                    gbp.setText(String.format("%.2f", eurV * kursEurGbp));
                } else {
                    eur.setText("");
                    gbp.setText("");
                }
            }
        });

        gbp.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (!gbp.getText().isEmpty()) {
                    double iznos = Double.parseDouble(gbp.getText());
                    double eurV = iznos / kursEurGbp;
                    eur.setText(String.format("%.2f", eurV));
                    usd.setText(String.format("%.2f", eurV * kursEurUsd));
                } else {
                    eur.setText("");
                    usd.setText("");
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new Zadatak3();
    }
}
