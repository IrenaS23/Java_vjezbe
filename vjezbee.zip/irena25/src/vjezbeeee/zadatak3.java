package vjezbeeee;

import java.util.Scanner;

	public class zadatak3 {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Unesi br el niza: ");
	        int n = sc.nextInt();
	        int[] niz = new int[n];
	        
	        System.out.println("Unesi el niza: ");
	        for (int i = 0; i < n; i++) {
	            niz[i] = sc.nextInt();
	        }

	        System.out.print("Unesi vrijednost x: ");
	        int x = sc.nextInt();

	 
	        for (int i = 0; i < n; i++) {
	            if (niz[i] % 2 == 0) {
	                niz[i] = niz[i] + x;
	            }
	        }

	    
	        System.out.println("Novi niz izgleda ovako: ");
	        for (int i = 0; i < n; i++) {
	            System.out.print(niz[i] + " ");
	        }

	    }
	}

