package vjezbeeee;

import java.util.Scanner;

public class zadatak5 {	
	    public static void main(String[] args) {
	        Scanner unos = new Scanner(System.in);

	        System.out.print("Unesi br el niza: ");
	        int n = unos.nextInt();
	        
	        int[] niz = new int[n];
	        
	        System.out.println("Unesi el niza: ");
	        for (int i = 0; i < n; i++) {
	            niz[i] = unos.nextInt();
	        }

	        int suma = 0;

	        for (int i = 0; i < n; i++) {
	            if (niz[i] < 0 && niz[i] % 2 == 0) {
	                suma += Math.abs(niz[i]);
	            }
	        }
	        System.out.println("Apsolutna suma negativnih parnih brojeva je: " + suma);
	    }
	}
