package domaci_vjezbe;

import java.util.Scanner;

public class poz_br {

	public static void main(String[] args) {
	   Scanner sc = new Scanner(System.in);

		        int n = sc.nextInt();
		        int[] niz = new int[n];
		        int brojPoz = 0;
		        
		        System.out.println("Unesi brojeve:");
		        for (int i = 0; i < n; i++) {
		            niz[i] = sc.nextInt();
		            if (niz[i] > 0) {
		                brojPoz++;
		            }
		        }

		        System.out.println("U nizu ima " + brojPoz + " pozitivnih brojeva."); 
		    }
		

	}


