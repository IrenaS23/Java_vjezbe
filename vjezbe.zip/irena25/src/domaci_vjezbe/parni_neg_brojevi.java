package domaci_vjezbe;

import java.util.Scanner;

public class parni_neg_brojevi {

   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] niz = new int[n];
        
        System.out.println("Unesi brojeve:");
        for (int i = 0; i < n; i++) {
            niz[i] = sc.nextInt();
        }

        System.out.println("Parni negativni brojevi u nizu su:");

        for (int i = 0; i < n; i++) {
            if (niz[i] < 0 && niz[i] % 2 == 0) {
                System.out.println(niz[i]);
            }
        }

        sc.close();
    }
}


