package drugizad;

public class Testna {
	
	public static void main(String[] args) {

        // Kreiramo restoran
        Restoran restoran = new Restoran("Bistro Kod Ane", "Njegoševa 12", "12345678");

        // Kreiramo zaposlene
        Konobar k1 = new Konobar("K1", "Marko", "Markovic", 10, 40, 5);
        Konobar k2 = new Konobar("K2", "Milos", "Milic", 11, 38, 3);
        Kuvar ku = new Kuvar("K3", "Jovan", "Jovic", 12, 37);
        Menadzer m1 = new Menadzer("M4", "Ana", "Anic", 15, 35, 500);
        Menadzer m2 = new Menadzer("M5", "Petar", "Petrovic", 16, 32, 800);

        // Dodajemo zaposlene u restoran
        restoran.dodajZaposlenog(k1);
        restoran.dodajZaposlenog(k2);
        restoran.dodajZaposlenog(ku);
        restoran.dodajZaposlenog(m1);
        restoran.dodajZaposlenog(m2);

        // Generišemo obračun plata
        restoran.generisiObracun("Novembar", 2025);

        // Ukupan trošak
        System.out.println();
        System.out.println("Ukupan trošak plata restorana: " + restoran.izracunajUkupanTrosak() + " €");
    }
}

