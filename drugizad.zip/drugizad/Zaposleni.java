package drugizad;

public class Zaposleni {

	    protected String id;
	    protected String ime;
	    protected String prezime;
	    protected double plataPoSatu;
	    protected double ukupanBrojSati;
	    

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getPrezime() {
		return prezime;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public double getPlataPoSatu() {
		return plataPoSatu;
	}

	public void setPlataPoSatu(double plataPoSatu) {
		this.plataPoSatu = plataPoSatu;
	}

	public double getUkupanBrojSati() {
		return ukupanBrojSati;
	}

	public void setUkupanBrojSati(double ukupanBrojSati) {
		this.ukupanBrojSati = ukupanBrojSati;
		
		
	}
public Zaposleni(String id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati) {
		super();
		this.id = id;
		this.ime = ime;
		this.prezime = prezime;
		this.plataPoSatu = plataPoSatu;
		this.ukupanBrojSati = ukupanBrojSati;
	}
public double izracunajPlatu() {
    return 0; 
}

@Override
public String toString() {
    return ime + " " + prezime +  "ID: " + id ;
}


public static void main(String[] args) {
		
}
}
