package drugizad;
public class Konobar extends Zaposleni {
    private double prekovremeniSati;

    public Konobar(String id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati, double prekovremeniSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.prekovremeniSati = prekovremeniSati;
    }

    @Override
    public double izracunajPlatu() {
        double redovniRad = ukupanBrojSati * plataPoSatu;
        double prekovremeniRad = prekovremeniSati * plataPoSatu * 1.2;
        return 4 * (redovniRad + prekovremeniRad);
    }
}