
class Telefon extends EProizvodi {
	
    private String operativniSistem;
    private double velicinaEkrana;

    public Telefon(String opisP, String sifraP, double UvoznaCijena, String operativniSistem, double velicinaEkrana) {
        super(opisP, sifraP, UvoznaCijena);
        this.operativniSistem = operativniSistem;
        this.velicinaEkrana = velicinaEkrana;
    }

    @Override
    public double getMaloprodajnaCijena() {
        return UvoznaCijena * 1.3 + velicinaEkrana * 15; 
    }

    
    @Override
    public String toString() {
        return super.toString() + " OS: " + operativniSistem + " Ekran: " + velicinaEkrana + "in, Maloprodajna cijena: " + getMaloprodajnaCijena();
    }
}
