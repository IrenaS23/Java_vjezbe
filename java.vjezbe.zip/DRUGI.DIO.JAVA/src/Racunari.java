
public class Racunari extends EProizvodi {

	
		 public String procesor;
		 public int memorija;

		    public Racunari(String opisP, String sifreP, double UvoznaCijena, String procesor, int memorija) {
		        super(opisP, sifreP, UvoznaCijena);
		        this.procesor = procesor;
		        this.memorija = memorija;
		    }

		   
		    @Override
		    public double getMaloprodajnaCijena() {
		        return UvoznaCijena * 1.25 + memorija * 10;
		    }
		    
		    @Override
		    public String toString() {
		        return super.toString() + ", Procesor: " + procesor + ", Memorija: " + memorija + "GB, Maloprodajna cijena: " + getMaloprodajnaCijena();
		    
		

	}


public static void main(String[] args) {
}
}