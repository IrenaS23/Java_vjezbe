
public class EProizvodi {

	public String opisP;
	public String sifreP;
	public double UvoznaCijena;
	
	
	public String getOpisp() {
		return opisP;
	}


	public void setOpisp(String opisp) {
		this.opisP = opisp;
	}


	public String getSifreP() {
		return sifreP;
	}


	public void setSifreP(String sifreP) {
		this.sifreP = sifreP;
	}


	public double getUvoznaCijena() {
		return UvoznaCijena;
	}


	public void setUvoznaCijena(double uvoznaCijena) {
		UvoznaCijena = uvoznaCijena;
	}

	public EProizvodi(String opisP, String sifreP, double uvoznaCijena) {
		super();
		this.opisP = opisP;
		this.sifreP = sifreP;
		UvoznaCijena = uvoznaCijena;
	}
	
	 public double getMaloprodajnaCijena() {
	        return UvoznaCijena * 1.2; 
	    }

	@Override
	public String toString() {
		return "EProizvodi [opisp=" + opisP + ", sifreP=" + sifreP + ", UvoznaCijena=" + UvoznaCijena + "]";
	}


	public static void main(String[] args) {
		

	}

}
