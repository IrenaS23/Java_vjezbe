import java.util.ArrayList;
import java.util.Scanner;

public class TestnaKlasa {
	
	public static void main(String[] args) {
		
	Scanner sc = new Scanner(System.in);
    ArrayList<EProizvodi> proizvodi = new ArrayList<>();
 
    proizvodi.add(new Racunari("Laptop Lenovo", "RA123", 800, "i5", 16));
    proizvodi.add(new Telefon("Samsung Galaxy", "TE456", 500, "Android", 6.5));
    proizvodi.add(new TV("LG", "TV889", 700, 55));

    
    System.out.println("Ako izaberete 1 - Unos uredjaja");
    System.out.println("Ako izaberete 2 -  Pregled svih uredjaja");
    System.out.println("Ako izaberete 3 -  Pregled uredjaja odredjenog tipa");
    
    System.out.print("Odaberi opciju: ");
    
    int izborKorisnika = sc.nextInt();
    
    if (izborKorisnika == 1) {
        System.out.print("Unesite opis: ");
        String opis = sc.nextLine();
        System.out.print("Unesite sifru:  ");
        String sifra = sc.nextLine().toUpperCase();
        System.out.print("Unesite uvoznu cijenu: ");
        double cijena = sc.nextDouble();
       
        if (sifra.startsWith("RA")) {
            System.out.print("Procesor: ");
            String procesor = sc.nextLine();
            System.out.print("Memorija : ");
            int mem = sc.nextInt();
            proizvodi.add(new Racunari(opis, sifra, cijena, procesor, mem));
        } else if (sifra.startsWith("TE")) {
            System.out.print("Operativni sistem: ");
            String os = sc.nextLine();
            System.out.print("Velicina ekrana : ");
            double ekran = sc.nextDouble();
            proizvodi.add(new Telefon(opis, sifra, cijena, os, ekran));
        } else if (sifra.startsWith("TV")) {
            System.out.print("Velicina ekrana: ");
            double ekran = sc.nextDouble();
            proizvodi.add(new TV(opis, sifra, cijena, ekran));
        } else {
            System.out.println("Nepoznata sifra ");
        }
    
        
    
    }else if(izborKorisnika ==2) {
    	
     }
    
    else if (izborKorisnika == 3) {
        System.out.print("Unesite tip (RA ili TE ili TV): ");
        String tip = sc.nextLine().toUpperCase();
        boolean nadjen = false;
        for (EProizvodi p : proizvodi) {
            if (p.sifreP.startsWith(tip)) {
                System.out.println(p);
                nadjen = true;
            }
        }
        if (!nadjen) System.out.println("Nema tog tipa.");
    }

    else {
        System.out.println("Nepostojeca opcija.");
} 
    
	}}
	


