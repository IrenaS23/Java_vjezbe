class TV extends EProizvodi {
    private double velicinaEkrana;

    public TV(String opisP, String sifraP, double UvoznaCijena, double velicinaEkrana) {
        super(opisP, sifraP, UvoznaCijena);
        this.velicinaEkrana = velicinaEkrana;
    }

    @Override
    public double getMaloprodajnaCijena() {
        return UvoznaCijena * 1.35 + velicinaEkrana * 20; 
    }

    @Override
    public String toString() {
        return super.toString() + " Ekran: " + velicinaEkrana + "in, Maloprodajna cijena: " + getMaloprodajnaCijena();
    }
}
