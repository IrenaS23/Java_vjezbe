import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Vozilo> vozila = new ArrayList<>();

        vozila.add(new Bicikl("B1", 20));
        vozila.add(new Motor("M1", 60));
        vozila.add(new Automobil("A1", 100));

        double udaljenost = 10;

        for (Vozilo v : vozila) {
            v.info();
            double vrijeme = v.izracunajVrijemeDostave(udaljenost);
            System.out.println("Vrijeme dostave: " + vrijeme + " sati");

            if (v instanceof Ekonomican) {
                Ekonomican e = (Ekonomican) v;
                double pot = e.potrosnjaPoKm() * udaljenost;
                System.out.println("Potrosnja: " + pot);
            }

            System.out.println("------------------");
        }

        System.out.println("Rezime:");
        System.out.println("Bicikl je najsporiji ali bez potrosnje.");
        System.out.println("Motor je brz i ekonomican.");
        System.out.println("Automobil je najbrzi ali trosi vise resursa.");
    }
}
